# Product guides and market policies

Fictional training publications. One guide per product; policies are shared by market.

| Document | PDF | Markdown |
|---|---|---|
| CloudStep Runner | Product and care guide | [PDF](products/cloudstep-care.pdf) | [Markdown](documents/cloudstep-care.md) |
| NightPace Runner | Use and maintenance | [PDF](products/nightpace-use.pdf) | [Markdown](documents/nightpace-use.md) |
| MetroFlex Runner | Textile care guide | [PDF](products/metroflex-care.pdf) | [Markdown](documents/metroflex-care.md) |
| StreetPro Runner | Everyday footwear guide | [PDF](products/streetpro-guide.pdf) | [Markdown](documents/streetpro-guide.md) |
| AeroKnit Runner | Road use guide | [PDF](products/aeroknit-guide.pdf) | [Markdown](documents/aeroknit-guide.md) |
| SwiftArc Runner | Product information | [PDF](products/swiftarc-guide.pdf) | [Markdown](documents/swiftarc-guide.md) |
| UrbanGlide | Knit upper care | [PDF](products/urbanglide-guide.pdf) | [Markdown](documents/urbanglide-guide.md) |
| TerraFlow Trail | Product scope and care | [PDF](products/terraflow-guide.pdf) | [Markdown](documents/terraflow-guide.md) |
| Velocity Knit | Product and care guide | [PDF](products/velocity-knit-guide.pdf) | [Markdown](documents/velocity-knit-guide.md) |
| FlexWeave Runner | Product and care guide | [PDF](products/flexweave-runner-guide.pdf) | [Markdown](documents/flexweave-runner-guide.md) |
| CloudRush | Product and care guide | [PDF](products/cloudrush-guide.pdf) | [Markdown](documents/cloudrush-guide.md) |
| RoadMuse | Product and care guide | [PDF](products/roadmuse-guide.pdf) | [Markdown](documents/roadmuse-guide.md) |
| PaceLine | Product and care guide | [PDF](products/paceline-guide.pdf) | [Markdown](documents/paceline-guide.md) |
| AirStride | Product and care guide | [PDF](products/airstride-guide.pdf) | [Markdown](documents/airstride-guide.md) |
| MotionGrid | Product and care guide | [PDF](products/motiongrid-guide.pdf) | [Markdown](documents/motiongrid-guide.md) |
| RunNova | Product and care guide | [PDF](products/runnova-guide.pdf) | [Markdown](documents/runnova-guide.md) |
| CityBounce | Product and care guide | [PDF](products/citybounce-guide.pdf) | [Markdown](documents/citybounce-guide.md) |
| TrailEcho | Product and care guide | [PDF](products/trailecho-guide.pdf) | [Markdown](documents/trailecho-guide.md) |
| SprintCore | Product and care guide | [PDF](products/sprintcore-guide.pdf) | [Markdown](documents/sprintcore-guide.md) |
| WaveTrack | Product and care guide | [PDF](products/wavetrack-guide.pdf) | [Markdown](documents/wavetrack-guide.md) |
| LightForm | Product and care guide | [PDF](products/lightform-guide.pdf) | [Markdown](documents/lightform-guide.md) |
| PulseRide | Product and care guide | [PDF](products/pulseride-guide.pdf) | [Markdown](documents/pulseride-guide.md) |
| ActiveLoop | Product and care guide | [PDF](products/activeloop-guide.pdf) | [Markdown](documents/activeloop-guide.md) |
| HorizonRun | Product and care guide | [PDF](products/horizonrun-guide.pdf) | [Markdown](documents/horizonrun-guide.md) |
| DashCraft | Product and care guide | [PDF](products/dashcraft-guide.pdf) | [Markdown](documents/dashcraft-guide.md) |
| TempoMesh | Product and care guide | [PDF](products/tempomesh-guide.pdf) | [Markdown](documents/tempomesh-guide.md) |
| StreetWave | Product and care guide | [PDF](products/streetwave-guide.pdf) | [Markdown](documents/streetwave-guide.md) |
| CoreMotion | Product and care guide | [PDF](products/coremotion-guide.pdf) | [Markdown](documents/coremotion-guide.md) |
| RidgeStep | Product and care guide | [PDF](products/ridgestep-guide.pdf) | [Markdown](documents/ridgestep-guide.md) |
| CometRun | Product and care guide | [PDF](products/cometrun-guide.pdf) | [Markdown](documents/cometrun-guide.md) |
| DailyPace | Product and care guide | [PDF](products/dailypace-guide.pdf) | [Markdown](documents/dailypace-guide.md) |
| GlideForm | Product and care guide | [PDF](products/glideform-guide.pdf) | [Markdown](documents/glideform-guide.md) |
| NovaFlex | Product and care guide | [PDF](products/novaflex-guide.pdf) | [Markdown](documents/novaflex-guide.md) |
| EchoStride | Product and care guide | [PDF](products/echostride-guide.pdf) | [Markdown](documents/echostride-guide.md) |
| MotionLite | Product and care guide | [PDF](products/motionlite-guide.pdf) | [Markdown](documents/motionlite-guide.md) |
| TrackBloom | Product and care guide | [PDF](products/trackbloom-guide.pdf) | [Markdown](documents/trackbloom-guide.md) |
| ZenithRun | Product and care guide | [PDF](products/zenithrun-guide.pdf) | [Markdown](documents/zenithrun-guide.md) |
| FlowMark | Product and care guide | [PDF](products/flowmark-guide.pdf) | [Markdown](documents/flowmark-guide.md) |
| UrbanPulse | Product and care guide | [PDF](products/urbanpulse-guide.pdf) | [Markdown](documents/urbanpulse-guide.md) |
| AeroStreet | Product and care guide | [PDF](products/aerostreet-guide.pdf) | [Markdown](documents/aerostreet-guide.md) |
| VectorRun | Product and care guide | [PDF](products/vectorrun-guide.pdf) | [Markdown](documents/vectorrun-guide.md) |
| SoftStride | Product and care guide | [PDF](products/softstride-guide.pdf) | [Markdown](documents/softstride-guide.md) |
| PeakMotion | Product and care guide | [PDF](products/peakmotion-guide.pdf) | [Markdown](documents/peakmotion-guide.md) |
| LoopRunner | Product and care guide | [PDF](products/looprunner-guide.pdf) | [Markdown](documents/looprunner-guide.md) |
| DriftPace | Product and care guide | [PDF](products/driftpace-guide.pdf) | [Markdown](documents/driftpace-guide.md) |
| RapidWeave | Product and care guide | [PDF](products/rapidweave-guide.pdf) | [Markdown](documents/rapidweave-guide.md) |
| MetroDash | Product and care guide | [PDF](products/metrodash-guide.pdf) | [Markdown](documents/metrodash-guide.md) |
| CloudLane | Product and care guide | [PDF](products/cloudlane-guide.pdf) | [Markdown](documents/cloudlane-guide.md) |
| MotionPeak | Product and care guide | [PDF](products/motionpeak-guide.pdf) | [Markdown](documents/motionpeak-guide.md) |
| FlexRoute | Product and care guide | [PDF](products/flexroute-guide.pdf) | [Markdown](documents/flexroute-guide.md) |
| Germany | Voluntary returns and promotion terms | [PDF](policies/returns-de.pdf) | [Markdown](documents/returns-de.md) |
| France | Voluntary returns and promotion terms | [PDF](policies/returns-fr.pdf) | [Markdown](documents/returns-fr.md) |
